// ProductController.java
public class ProductController {
    private ProductRepository repository;
    private ProductView view;

    public ProductController(ProductRepository repository, ProductView view) {
        this.repository = repository;
        this.view = view;
    }

    public void addProduct(String name, double price) {
        Product product = new Product(name, price);
        repository.addProduct(product);
        view.showMessage("Producto agregado: " + name);
    }

    public void updateProductPrice(String name, double newPrice) {
        Product product = repository.findProductByName(name);
        if (product != null) {
            product.setPrice(newPrice);
            view.showMessage("Precio actualizado para: " + name);
        } else {
            view.showMessage("Producto no encontrado: " + name);
        }
    }

    public void displayAllProducts() {
        view.displayProducts(repository.getAllProducts());
    }
}
