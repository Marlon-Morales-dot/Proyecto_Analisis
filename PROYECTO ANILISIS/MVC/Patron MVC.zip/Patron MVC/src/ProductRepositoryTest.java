// ProductRepositoryTest.java
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ProductRepositoryTest {
    @org.junit.Test
    @Test
    public void testAddProduct() {
        ProductRepository repo = new ProductRepository();
        Product product = new Product("Laptop", 1500.0);
        repo.addProduct(product);
        assertEquals(1, repo.getAllProducts().size());
        assertEquals("Laptop", repo.getAllProducts().get(0).getName());
    }

    @Test
    public void testFindProductByName() {
        ProductRepository repo = new ProductRepository();
        Product product = new Product("Phone", 800.0);
        repo.addProduct(product);
        Product foundProduct = repo.findProductByName("Phone");
        assertNotNull(foundProduct);
        assertEquals(800.0, foundProduct.getPrice());
    }
}
