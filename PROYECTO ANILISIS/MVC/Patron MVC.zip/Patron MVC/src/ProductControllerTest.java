// ProductControllerTest.java
import org.junit.jupiter.api.Test;

import static jdk.internal.org.objectweb.asm.util.CheckClassAdapter.verify;
import static junit.framework.TestCase.assertEquals;

public class ProductControllerTest {
    @org.junit.Test
    @Test
    public void testAddProduct() {
        ProductRepository repo = new ProductRepository();
        ProductView view = mock(ProductView.class);
        ProductController controller = new ProductController(repo, view);

        controller.addProduct("Tablet", 300.0);

        verify(view).showMessage("Producto agregado: Tablet");
        assertEquals(1, repo.getAllProducts().size());
    }

    private ProductView verify(ProductView view){

    }

    private ProductView mock(Class<ProductView> productViewClass) {
        return null;
    }

    @org.junit.Test
    @Test
    public void testUpdateProductPrice() {
        ProductRepository repo = new ProductRepository();
        ProductView view = mock(ProductView.class);
        ProductController controller = new ProductController(repo, view);

        Product product = new Product("Camera", 500.0);
        repo.addProduct(product);

        controller.updateProductPrice("Camera", 550.0);
        verify(view).showMessage("Precio actualizado para: Camera");
        assertEquals(550.0, repo.findProductByName("Camera").getPrice());
    }

    @org.junit.Test
    @Test
    public void testUpdateProductPriceProductNotFound() {
        ProductRepository repo = new ProductRepository();
        ProductView view = mock(ProductView.class);
        ProductController controller = new ProductController(repo, view);

        controller.updateProductPrice("Smartwatch", 200.0);
        verify(view).showMessage("Producto no encontrado: Smartwatch");
    }
}
