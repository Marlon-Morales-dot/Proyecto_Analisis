// ProductView.java
import java.util.List;

public class ProductView {
    public void displayProducts(List<Product> products) {
        System.out.println("Lista de Productos:");
        for (Product product : products) {
            System.out.println("Nombre: " + product.getName() + " | Precio: $" + product.getPrice());
        }
    }

    public void showMessage(String message) {
        System.out.println(message);
    }
}
