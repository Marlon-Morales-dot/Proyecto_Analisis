// Main.java
public class Main {
    public static void main(String[] args) {
        ProductRepository repository = new ProductRepository();
        ProductView view = new ProductView();
        ProductController controller = new ProductController(repository, view);

        controller.addProduct("Laptop", 1200.0);
        controller.addProduct("Phone", 800.0);
        controller.displayAllProducts();
        controller.updateProductPrice("Phone", 850.0);
        controller.displayAllProducts();
    }
}
