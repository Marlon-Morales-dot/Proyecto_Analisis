import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class ObserverPatternTest {
    private ConcreteSubject subject;
    private ConcreteObserver observer1;
    private ConcreteObserver observer2;

    @Before
    public void setUp() {
        subject = new ConcreteSubject();
        observer1 = new ConcreteObserver(subject);
        observer2 = new ConcreteObserver(subject);

        subject.registerObserver(observer1);
        subject.registerObserver(observer2);
    }

    @Test
    public void testObserversNotifiedOnStateChange() {
        subject.setState("Estado 1");
        assertEquals("Estado 1", subject.getState());

        subject.setState("Estado 2");
        assertEquals("Estado 2", subject.getState());
    }

    @Test
    public void testObserverUnregistered() {
        subject.removeObserver(observer1);
        subject.setState("Estado 3");

        assertEquals("Estado 3", subject.getState());
        // Aquí podrías validar que el observador 1 ya no recibe actualizaciones
    }
}
