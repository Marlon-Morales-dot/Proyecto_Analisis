import org.example.Subject;

import java.util.ArrayList;
import java.util.List;
import java.util.Observer;

public class ConcreteSubject implements Subject {
    private List<Observer> observers = new ArrayList<>();
    private String state;  // Estado que cambia y que se notificará a los observadores.

    @Override
    public void registerObserver(Observer o) {
        observers.add(o);
    }

    @Override
    public void removeObserver(Observer o) {
        observers.remove(o);
    }

    @Override
    public void notifyObservers() {
        for (Observer observer : observers) {
            observer.update();
        }
    }

    public void setState(String state) {
        this.state = state;
        notifyObservers();  // Notifica a los observadores cuando cambia el estado.
    }

    public String getState() {
        return state;
    }

    @Override
    public String toString() {
        return "ConcreteSubject: " + state;
    }
}