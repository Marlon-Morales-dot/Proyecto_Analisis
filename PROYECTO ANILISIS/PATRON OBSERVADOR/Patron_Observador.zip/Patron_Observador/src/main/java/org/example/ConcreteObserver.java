public class ConcreteObserver implements Observer {
    private ConcreteSubject subject;

    public ConcreteObserver(ConcreteSubject subject) {
        this.subject = subject;
    }

    @Override
    public void update() {
        // Actualización cuando el estado del sujeto cambia.
        System.out.println("Estado actualizado a: " + subject.getState());
    }

    @Override
    public String toString() {
        return "ConcreteObserver observando: " + subject.getState();
    }
}