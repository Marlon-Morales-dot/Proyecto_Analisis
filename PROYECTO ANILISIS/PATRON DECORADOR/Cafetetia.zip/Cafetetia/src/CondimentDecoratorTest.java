import org.junit.jupiter.api.Test;

import static junit.framework.TestCase.assertEquals;

public class CondimentDecoratorTest {

    @Test
    public void testEspressoWithMilkAndMocha() {
        Beverage beverage = new Espresso();
        beverage = new Milk(beverage);
        beverage = new Mocha(beverage);
        assertEquals(2.29f, beverage.cost(), 0.01);
        assertEquals("Espresso, Milk, Mocha", beverage.getDescription());
    }

    @Test
    public void testDarkRoastWithSoy() {
        Beverage beverage = new DarkRoast();
        beverage = new Soy(beverage);
        assertEquals(1.14f, beverage.cost(), 0.01);
        assertEquals("Dark Roast Coffee, Soy", beverage.getDescription());
    }

    @Test
    public void testHouseBlendWithMultipleCondiments() {
        Beverage beverage = new HouseBlend();
        beverage = new Soy(beverage);
        beverage = new Milk(beverage);
        assertEquals(1.14f, beverage.cost(), 0.01);
        assertEquals("House Blend Coffee, Soy, Milk", beverage.getDescription());
    }
}
