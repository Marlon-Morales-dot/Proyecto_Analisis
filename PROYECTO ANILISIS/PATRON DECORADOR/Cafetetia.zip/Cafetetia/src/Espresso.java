public class Espresso extends Beverage {
    public Espresso() {
        description = "Espresso";
    }

    @Override
    public float cost() {
        return 1.99f;
    }
}

public class HouseBlend extends Beverage {
    public HouseBlend() {
        description = "House Blend Coffee";
    }

    @Override
    public float cost() {
        return 0.89f;
    }
}

public class DarkRoast extends Beverage {
    public DarkRoast() {
        description = "Dark Roast Coffee";
    }

    @Override
    public float cost() {
        return 0.99f;
    }
}

public class Decaf extends Beverage {
    public Decaf() {
        description = "Decaf Coffee";
    }

    @Override
    public float cost() {
        return 1.05f;
    }
}
