import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class BeverageTest {

    @Test
    public void testEspresso() {
        Beverage beverage = new Espresso();
        assertEquals(1.99f, beverage.cost(), 0.01);
        assertEquals("Espresso", beverage.getDescription());
    }

    @Test
    public void testHouseBlend() {
        Beverage beverage = new HouseBlend();
        assertEquals(0.89f, beverage.cost(), 0.01);
        assertEquals("House Blend Coffee", beverage.getDescription());
    }
}
