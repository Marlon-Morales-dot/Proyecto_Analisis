import org.junit.jupiter.api.Test;

import static junit.framework.TestCase.assertEquals;

public class AdditionalCondimentsTest {

    @Test
    public void testEspressoWithSugarAndCream() {
        Beverage beverage = new Espresso();
        beverage = new Sugar(beverage);
        beverage = new Cream(beverage);
        assertEquals(2.29f, beverage.cost(), 0.01); // Espresso 1.99 + Sugar 0.05 + Cream 0.25
        assertEquals("Espresso, Sugar, Cream", beverage.getDescription());
    }

    @Test
    public void testDecafWithCreamAndMilk() {
        Beverage beverage = new Decaf();
        beverage = new Cream(beverage);
        beverage = new Milk(beverage);
        assertEquals(1.40f, beverage.cost(), 0.01); // Decaf 1.05 + Cream 0.25 + Milk 0.10
        assertEquals("Decaf Coffee, Cream, Milk", beverage.getDescription());
    }
}
